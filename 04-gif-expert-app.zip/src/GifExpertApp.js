
import React from 'react';
import './index.css';

export const GifExpertApp = () => {
    return (
        <>
        <h2>GifExpertApp</h2>,
        <hr></hr>
        </>
    );
}
